<?php

namespace Protection\UpDate;

use pocketmine\Server;
use pocketmine\event\Listener;
use pocketmine\utils\TextFormat;
use pocketmine\utils\Utils;
use pocketmine\scheduler\CallbackTask;
use pocketmine\event\server\ServerCommandEvent;


class UpDate implements Listener{
	
	/*
	此类用于检测保护插件请不要做任何修改 !
	This class used to detect protection plug-in, please don't make any changes !
	*/
	
	public function __construct($plugin){
		$this->plugin = $plugin;
		$this->v = $this->plugin->getFullName();
		$this->np = $this->plugin->getName();
		$this->url = $this->plugin->url;
		$this->UpDate();
		$this->stop = false;
	}
	
	public function UpDate(){
		$this->Server = Server::getInstance();
		$code = Utils::getURL($this->url, 1);
		$this->Server->getScheduler()->scheduleRepeatingTask(new CallbackTask([$this,"reUpDate"]), 60*20);
		//$this->Server->getPluginManager()->registerEvents($this, $this);
		if($code == "nopermission"){
			$plugin = $this->Server->getPluginManager()->getPlugin($this->np);
			$this->Server->getPluginManager()->disablePlugin($plugin);
		    $this->stop = true;
			$this->Server->getLogger()->info("[{$this->np}] ".TextFormat::RED."你没有权限使用{$this->np} !");
		return;
		}
	    preg_match("/^(Name:)?([A-z]+)?([\n])?(Version:)?([\S]+)?([\n])?(Change:)?([^\/]+)/i",$code,$out);
		if(isset($out[2])){
		if($out[2]==$this->np){
			preg_match_all("[\d]",$out[5],$version);
			preg_match_all("[\d]",$this->v,$version2);
			$v = null;
			$ov = null;
			foreach($version[0] as $vn){
				$v.="$vn";}
			foreach($version2[0] as $von){
				$ov.="$von";}				
			if($ov < $v){
				$this->Server->getLogger()->info("[{$this->np}] ".TextFormat::YELLOW."发现本插件新版本${out[5]} !");
				$this->Server->getLogger()->info("[{$this->np}] ".TextFormat::YELLOW."${out[8]}");
			    return;
			}
		$this->Server->getLogger()->info("[{$this->np}] ".TextFormat::BLUE."插件加载成功,你目前使用的版本为".TextFormat::GREEN."最新版!");
	    return;
		}}
		$this->Server->getLogger()->info("[{$this->np}] ".TextFormat::BLUE."插件加载成功 ".TextFormat::GOLD."更新检查失败!");
	}

	public function reUpDate(){
		$code = Utils::getURL($this->url, 1);
		if($code == "nopermission" and $this->stop != true){
			$plugin = $this->Server->getPluginManager()->getPlugin($this->np);
			$this->Server->getPluginManager()->disablePlugin($plugin);
			$this->stop = true;
		    $this->Server->getLogger()->info("[{$this->np}] ".TextFormat::RED."检测发现,你被判断非法使用{$this->np}插件已停用 !");
		return;
		}
	}

	public function onServercmd(ServerCommandEvent $event){
	    $cmd = strtolower($event->getCommand());
		$np = strtolower($this->np);
		if($cmd == "extractplugin $np"){
			$this->Server->getLogger()->info(TextFormat::RED."请不要尝试解包，已向服务器发送数据");
			$event->setCancelled(true);	
		}
	}
}