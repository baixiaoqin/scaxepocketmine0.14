<?php

/*
 *  ______   _____    ______  __   __  ______
 * /  ___/  /  ___|  / ___  \ \ \ / / |  ____|
 * | |___  | |      | |___| |  \ / /  | |____
 * \___  \ | |      |  ___  |   / /   |  ____|
 *  ___| | | |____  | |   | |  / / \  | |____
 * /_____/  \_____| |_|   |_| /_/ \_\ |______|
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * @author Sunch233#3226 QQ2125696621 And KKK
 * @link https://github.com/ScaxeTeam/Scaxe/
 *
*/

namespace pocketmine\block;

use pocketmine\item\Item;
use pocketmine\level\Level;
use pocketmine\Player;

use pocketmine\item\Tool;
use pocketmine\math\Vector3;
use pocketmine\network\protocol\UpdateBlockPacket;

class DoublePlant extends Flowable{

	protected $id = self::DOUBLE_PLANT;

	public function __construct($meta = 0){
		$this->meta = $meta;
	}

	public function canBeReplaced(){
		return true;
	}

	public function getName() : string{
		static $names = [
			0 => "Sunflower",
			1 => "Lilac",
			2 => "Double Tallgrass",
			3 => "Large Fern",
			4 => "Rose Bush",
			5 => "Peony"
		];
		return $names[$this->meta & 0x05];
	}

	public function onUpdate($type){
		if(($this->meta & 0x08) === 0x08){ // This is the Top part of flower
			$down = $this->getSide(Vector3::SIDE_DOWN);
			if($down->getId() === 0){
				$this->getLevel()->setBlock($this, Block::get(Block::AIR), false);
			}
		}else{
			//$up = $this->getSide(Vector3::SIDE_UP);
		}

		return true;
	}

	public function place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null){
		$down = $this->getSide(0);
		$up = $this->getSide(1);
		if($down->getId() === self::GRASS or $down->getId() === self::DIRT){
			$this->getLevel()->setBlock($block, $this, true);
			$this->getLevel()->setBlock($up, Block::get($this->id, $this->meta ^ 0x08), true);
			return true;
		}
		return false;
	}

	public function onBreak(Item $item){
		$up = $this->getSide(Vector3::SIDE_UP);
		$down = $this->getSide(Vector3::SIDE_DOWN);
		if(($this->meta & 0x08) === 0x08){ // This is the Top part of flower
			/*if($up->getId() === $this->id and $up->meta !== 0x08){ // Checks if the block ID and meta are right
				$this->getLevel()->setBlock($up, new Air(), true, false);
			}elseif($down->getId() === $this->id and $down->meta !== 0x08){
				echo($this->y."顶部被破坏\n");
				$this->getLevel()->setBlock($down, new Air(), true, false);
			}*/
			
			if($down->getId() === $this->id and ($down->meta & 0x08) !== 0x08){
				$this->getLevel()->setBlock($down, Block::get(Block::AIR), false, true);
				//$this->getLevel()->setBlock($down, new Air(), true);
			}
		}else{ // Bottom Part of flower
			/*if($up->getId() === $this->id and ($up->meta & 0x08) === 0x08){
				echo($this->y."底部被破坏\n");
				$this->getLevel()->setBlock($up, new Air(), true, false);
			}elseif($down->getId() === $this->id and ($down->meta & 0x08) === 0x08){
				$this->getLevel()->setBlock($down, new Air(), true, false);
			}*/
			
			if($up->getId() === $this->id and ($up->meta & 0x08) === 0x08){
				$this->getLevel()->setBlock($up, Block::get(Block::AIR), false, true);
				//$this->getLevel()->setBlock($up, new Air(), true);
			}
		}
		parent::onBreak($item);
		return true;
	}

	public function getDrops(Item $item) : array{
		/*if(($this->meta & 0x08) !== 0x08){
			return [[Item::DOUBLE_PLANT, $this->meta, 1]];
		}else{
			return [];
		}*/
		if(mt_rand(0, 24) === 0){
			return [[Item::SEEDS, 0, 1]];
		}else{
			return [];
		}
	}
}
