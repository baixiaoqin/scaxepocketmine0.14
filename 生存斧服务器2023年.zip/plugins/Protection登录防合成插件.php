<?php

namespace ProtectionFixCraft;

use pocketmine\event\Listener;
use pocketmine\event\inventory\CraftItemEvent;
use pocketmine\plugin\PluginBase;
/**
 * @name ProtectionFixCraft
 * @description 神秘的防未登成物品
 * @author Windows1145
 * @version 0.0.1
 * @main ProtectionFixCraft\Main
 * @api 2.0.0
 */
class Main extends PluginBase implements Listener {

    public function onEnable() {
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        $this->getLogger()->info("防未登录合成插件加载");
        $this->protection = $this->getServer()->getPluginManager()->getPlugin("Protection");
    }

    public function onCraft(CraftItemEvent $e) {
        $p = $e->getPlayer();
        if($this->protection !== null) {
            $this->protection->permission($e);
            if($e->isCancelled()) {
                $p->sendTip("§c你未登录！");
                return;
            }
        }
    }
	/*
	记得在登录插件protection.php的360多行加上
		public function onCraft(\pocketmine\event\inventory\CraftItemEvent $event){
		$this->permission($event);
	}
	这个不是代码中的 提示:onInventoryOpen
	*/
}
