<?php

namespace Protection\database;

use pocketmine\Server;
use pocketmine\utils\TextFormat;
use pocketmine\utils\Config;

class Sban{
	
	public function __construct($file){	
        $this->sban = new Config($file."Sban-list.yml", Config::YAML);
	}
	public function getall(){
		return $this->sban->getall();
	}
	public function set($key,$value){
		$this->sban->set($key,$value);
		$this->sban->save();
	}
	public function get($key){
		return $this->sban->get($key);
	}
	public function setall($array){
		$this->sban->setall($array);
		$this->sban->save();
	}
	public function getSban($name,$ip){
		$server = Server::getInstance();
		$banlist = $this->getall();
		$name = strtolower($name);
		foreach($banlist as $bname => $bip){
			$sbname = strtolower($bname);
			if($name == $sbname){
				$server->getLogger()->info("[Sban] ".TextFormat::RED."$name 在黑名单列表，禁止加入");
				return true;
			}
			if($ip == $bip){
				$server->getLogger()->info("[Sban] ".TextFormat::RED."$name 无法加入游戏,因：".TextFormat::YELLOW."于玩家$bname 同一IP,禁止加入");
				return true;
			}
		}
		return false;
	}
	
}